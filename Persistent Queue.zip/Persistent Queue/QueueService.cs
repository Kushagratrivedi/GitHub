﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Implementation of <see cref="IQueueService"/>
   /// </summary>
   public class QueueService : IQueueService
   {
      private readonly IFileManager _manager;
      private static readonly object _en_lock = new object();

      /// <summary>
      /// Default Constructor
      /// </summary>
      public QueueService(string _queueLocation)
      {
         _manager = new FileManager(_queueLocation);
      }

      /// <summary>
      /// Dequeues the data from the persistent queue
      /// </summary>
      /// <returns></returns>
      public IQueueItem Dequeue()
      {
         IQueueItem _item = null;
         try
         {
            // Get the least recent file
            var _fileName = this._manager.GetLeastRecentFile();

            // read the data
            var _data = this._manager.Read(_fileName);

            // rename the file to current stage
            var _newFileName = this._manager.Rename(_fileName, Stage.Dequeuing);

            if (_data == null)
            {
               throw new Exception("Unable to dequeue the item");
            }

            // deserialize the object
            object _queueitem = Serializer.Deserialize(_data);
            _item = new FileSystemQueueItem
            {
               CurrentStage = Stage.Dequeuing,
               FilePath = System.IO.Path.Combine(_manager.WorkingDirectory, _newFileName),
               Data = _queueitem
            };
         }
         catch (Exception ex)
         {
            Console.WriteLine(ex.StackTrace);
         }
         return _item;
      }

      /// <summary>
      /// Enqueues the item to the Persistent queue
      /// </summary>
      /// <param name="item">item to be queued</param>
      /// <returns><c>true</c>if item will be queued successfully, <c>false</c> otherwise.</returns>
      public IQueueItem Enqueue(object item)
      {
         IFileSystemQueueItem queueItem = null;
         try
         {
            lock (_en_lock)
            {
               // creates the queue item
               queueItem = new FileSystemQueueItem() { FilePath = _manager.CreateFile(), Data = item };

               // serialize it
               byte[] buffer = Serializer.Serialize(item);

               // write it to the file
               _manager.Write(buffer, queueItem.FilePath);

               // update the stage for the file
               _manager.Rename(queueItem.Name, Stage.Queued);

               // updat the stage for queue item
               queueItem.CurrentStage = Stage.Queued;
            }
         }
         catch (Exception ex)
         {
            Console.WriteLine(string.Format("Unable to queue the item, Error = {0}", ex.StackTrace));
         }
         return queueItem;
      }

      /// <summary>
      /// Gets the Number of unprocessed items
      /// </summary>
      /// <returns></returns>
      public int GetUnprocessedFileCounts()
      {
         int count = 0;
         try
         {
            var _ext = StageUtil.GetFileExtension(Stage.Queued);
            count = _manager.Scan(true).Where(k => k.EndsWith(_ext)).Count();
         }
         catch (IOException ex)
         {
            Console.WriteLine(string.Format("Unable to get unprocessed file counts, Error = {0}", ex.Message));
         }
         return count;
      }

      /// <summary>
      /// clean the processed items
      /// </summary>
      /// <param name="name"></param>
      public void AcknowledgeItemProcessed(string name)
      {
         try
         {
            // Update the stage and delete the file
            // Rename is the least expensive operation of file system
            // that's why we will first change the stage
            // In case of crash, all files marked by this stage
            // will be truncated on the application restart
            // if they have not be truncated yet.
            var _deleteFile = this._manager.Rename(name, Stage.Dequeued);
            this._manager.Delete(_deleteFile);
         }
         catch (Exception ex)
         {
            Console.WriteLine(string.Format("Unable to acknowledge the processed item, File Name = {0}", name));
         }
      }
   }
}
