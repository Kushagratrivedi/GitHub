﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// interface for managing Queue Item Related functionanlity
   /// </summary>
   public interface IQueueItem
   {
      /// <summary>
      /// Current Stage of the Queue Item
      /// </summary>
      Stage CurrentStage { set;  get; }

      /// <summary>
      /// Name of the queue item
      /// </summary>
      string Name { get; }

      /// <summary>
      /// 
      /// </summary>
      object Data { set; get; }
   }
}
