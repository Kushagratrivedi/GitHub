﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Implementation of <see cref="IFileManager"/>
   /// </summary>
   public class FileManager : IFileManager
   {
      private readonly string _directory;

      /// <summary>
      /// Constructor
      /// </summary>
      /// <param name="directory">Location of the directory</param>
      public FileManager(string directory)
      {
         if (string.IsNullOrEmpty(directory))
         {
            throw new Exception("Directory name cannot be null or empty");
         }

         if(!Directory.Exists(directory))
         {
            throw new DirectoryNotFoundException(directory);
         }

         _directory = directory;
      }

      /// <summary>
      /// Default Constructor
      /// </summary>
      public FileManager() : this (string.Empty)
      {

      }


      /// <summary>
      /// Gets current working directory
      /// </summary>
      public string WorkingDirectory { get { return this._directory; } }

      /// <summary>
      /// Create a new file
      /// </summary>
      /// <returns>File Stream of newly created file</returns>
      public string CreateFile()
      {
         if (string.IsNullOrEmpty(_directory))
         {
            throw new InvalidDataException("Directory path cannot be empty or null.");
         }

         if (!Directory.Exists(_directory))
         {
            throw new DirectoryNotFoundException(_directory);
         }

         var tickCount = DateTime.Now.Ticks.ToString();
         var stage = StageUtil.GetFileExtension(Stage.Queuing);

         string _filepath = Path.Combine(_directory, string.Format("{0}.{1}",tickCount, stage));

         FileStream file = null;

         try
         {
            file = File.Create(_filepath);
         }
         catch (IOException ex)
         {
            Console.WriteLine(string.Format("Unable to create the file. File Path = {0}", _filepath));
            throw ex;
         }
         finally
         {
            if (file != null)
            {
               file.Close();
            }
         }

         return _filepath;
      }

      /// <summary>
      /// Deletes the file
      /// </summary>
      /// <param name="fileName">Path of the file to be deleted</param>
      public void Delete(string fileName)
      {
         if (string.IsNullOrEmpty(fileName))
         {
            throw new ArgumentNullException("fileName");
         }

         string _filePath = null;
         try
         {
            _filePath = Path.Combine(_directory, fileName);

            if(!File.Exists(_filePath))
            {
               throw new FileNotFoundException(_filePath);
            }

            File.Delete(_filePath);
         }
         catch (IOException ex)
         {
            Console.WriteLine(string.Format("Unable to delete the file, File Path = {0}", _filePath));
            throw ex;
         }
      }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="files"></param>
      public void DeleteAll(IEnumerable<string> files)
      {
         if (files == null || !files.Any())
         {
            return;
         }

         foreach (var file in files)
         {
            try
            {
               this.Delete(file);
            }
            catch (Exception ex)
            {
               Console.WriteLine(string.Format("Unable to clear the file, File = {0}", file));
            }
         }
      }

      /// <summary>
      /// Read the data from the file and write to the buffer
      /// </summary>
      /// <param name="fileName">name of the file name</param>
      public byte[] Read(string fileName)
      {

         if (string.IsNullOrEmpty(fileName))
         {
            throw new ArgumentNullException("fileName");
         }

         string _filePath = Path.Combine(_directory, fileName);

         if (!File.Exists(_filePath))
         {
            throw new FileNotFoundException(fileName);
         }
         
         // start reading the data from the file to buffer
         using (var _reader = File.OpenRead(_filePath))
         {
            int length = (int)_reader.Length;
            byte[] buffer = new byte[length];
            int bytesToRead = length;
            int bytesRead = 0;

            while (bytesToRead > 0)
            {
               int n = _reader.Read(buffer, bytesRead, bytesToRead);
               if (n <= 0)
                  break;
               bytesToRead -= n;
               bytesRead += n;
            }
            return buffer;
         }
      }

      /// <summary>
      /// Rename the file based on new stage
      /// </summary>
      /// <param name="fileName">current name of the file</param>
      /// <param name="newStagstage">new stage</param>
      public string Rename(string fileName, Stage newStagstage)
      {
         if (string.IsNullOrEmpty(fileName))
         {
            throw new ArgumentNullException("fileName");
         }

         string _filePath = Path.Combine(_directory, fileName);
         if (!File.Exists(_filePath))
         {
            throw new FileNotFoundException(_filePath);
         }

         // Rename the file
         string extension = StageUtil.GetFileExtension(newStagstage);

         string newFileName = GetNewFileName(fileName, extension);

         string _newFilePath = Path.Combine(_directory, newFileName);

         try
         {
            File.Move(_filePath, _newFilePath);
         }
         catch (IOException ex)
         {
            Console.WriteLine(string.Format("Unable to rename the file, File = {0}", fileName));
            throw ex;
         }
         return newFileName;
      }

      /// <summary>
      /// Scans throgh the directory and collects the fileName (Including their Paths)
      /// </summary>
      /// <param name="includePath"><c>true</c>returns absolute file path, otherwise <c>file name</c></param>
      /// <returns>list of files residing inside the directory</returns>
      public IEnumerable<string> Scan(bool includePath)
      {
         var _files =  Directory.GetFiles(_directory);

         return includePath ? _files : _files.Select(k => Path.GetFileName(k));
      }

      /// <summary>
      /// Writes the data to the file
      /// </summary>
      /// <param name="buffer">data</param>
      /// <param name="fileName">Name of the file where data will be written</param>
      public void Write(byte[] buffer, string fileName)
      {
         // There is nothing to write, so return
         if (buffer == null || buffer.Length == 0)
         {
            return;
         }

         if (string.IsNullOrEmpty(fileName))
         {
            throw new ArgumentNullException(fileName);
         }

         var _filePath = Path.Combine(_directory, fileName);

         if(!File.Exists(_filePath))
         {
            throw new FileNotFoundException(_filePath);
         }

         // write data to buffer
         using (var _writer = File.OpenWrite(_filePath))
         {
            int length = buffer.Length; 
            _writer.Write(buffer, 0, length);
         }
      }

      /// <summary>
      /// Gets the oldest file from the directory
      /// </summary>
      /// <returns></returns>
      public string GetLeastRecentFile()
      {
         var _files = this.Scan(true);
         if (_files == null || !_files.Any())
         {
            return null;
         }
         var _leastRecentFile = (from file in _files
                                 where file.EndsWith(StageUtil.GetFileExtension(Stage.Queued))
                                 orderby File.GetLastWriteTime(file)
                                 select file).First();

         return _leastRecentFile;
      }

      /// <summary>
      /// Gets the file name with new extension
      /// </summary>
      /// <param name="fileName"></param>
      /// <param name="extension"></param>
      /// <returns></returns>
      private string GetNewFileName(string fileName, string extension)
      {
         string newFileName = null;
         try
         {
            var ext = Path.GetExtension(fileName);
            if(string.IsNullOrEmpty(ext) || StageUtil.GetStage(ext) == Stage.Unknown)
            {
               throw new IOException(string.Format("Unexpected file format, File = {0}", fileName));
            }

            newFileName = string.Format("{0}.{1}", Path.GetFileNameWithoutExtension(fileName), extension);
         }
         catch (IOException ex)
         {
            Console.WriteLine(string.Format("Unable to change the file Extension, File Name = {0}", fileName));
            throw ex;
         }

         return newFileName;
      }
   }
}
