﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Interface managing the queue services
   /// </summary>
   public interface IQueueService
   {
      /// <summary>
      /// Enqueues the new item to the persistent queue
      /// </summary>
      /// <param name="item">Item to be queued</param>
      /// <returns>Newly created item</returns>
      IQueueItem Enqueue(object item);

      /// <summary>
      /// Dequeues the item from the persistent queue
      /// </summary>
      /// <param name="item">item to be dequequed</param>
      /// <returns>dequed item</returns>
      IQueueItem Dequeue();

      /// <summary>
      /// Gets number of unprocessed items
      /// </summary>
      /// <returns></returns>
      int GetUnprocessedFileCounts();

      /// <summary>
      /// Clen the processed item
      /// </summary>
      /// <param name="name"></param>
      void AcknowledgeItemProcessed(string name);
   }
}
