using System;
using System.Collections.Generic;
using System.Linq;

namespace PersistentQueue
{
   /// <summary>
   /// Enum for managing the life cycle of the queue item
   /// </summary>
   public enum Stage
   {
      /// <summary>
      /// Item is currently being queued
      /// </summary>
      Queuing,

      /// <summary>
      /// Item has been queued successfully (Commmited to file system)
      /// </summary>
      Queued,

      /// <summary>
      /// Item is currently being processed 
      /// </summary>
      Dequeuing,

      /// <summary>
      /// Item has been processed successfully 
      /// </summary>
      Dequeued,

      /// <summary>
      /// Unknown
      /// </summary>
      Unknown
   }

   /// <summary>
   /// Utility class for stages
   /// </summary>
   public static class StageUtil
   {

      /// <summary>
      /// Gets the stage from the file extension
      /// </summary>
      /// <param name="extenstion">persisten queue item file extension</param>
      /// <returns>current stage of the item</returns>
      public static Stage GetStage(string extenstion)
      {
         Stage stage = Stage.Unknown;
         switch (extenstion)
         {
            case "001":
               stage = Stage.Queuing;
               break;
            case "002":
               stage = Stage.Queued;
               break;
            case "003":
               stage = Stage.Dequeuing;
               break;
            case "004":
            default:
               stage = Stage.Dequeued;
               break;
         }

         return stage;
      }

      /// <summary>
      /// Utility function to get the file extention from the current stage of queue item
      /// </summary>
      /// <param name="stage"></param>
      /// <returns>extension for the file name of the queue item</returns>
      public static string GetFileExtension(Stage stage)
      {
         string extension = null;

         switch (stage)
         {
            case Stage.Queuing:
               extension = "001";
               break;
            case Stage.Queued:
               extension = "002";
               break;
            case Stage.Dequeuing:
               extension = "003";
               break;
            case Stage.Dequeued:
            default:
               extension = "004";
               break;
         }

         return extension;
      }

      /// <summary>
      /// Gets the next stage
      /// </summary>
      /// <param name="currentStage"></param>
      /// <returns></returns>
      public static Stage GetNextStage(Stage currentStage)
      {
         Stage nextStage = Stage.Unknown;
         switch (currentStage)
         {
            case Stage.Queuing:
               nextStage = Stage.Queued;
               break;

            case Stage.Queued:
               nextStage = Stage.Dequeuing;
               break;

            case Stage.Dequeuing:
               nextStage = Stage.Dequeued;
               break;

            default:
               nextStage = Stage.Unknown;
               break;

         }
         return nextStage;
      }
   }
}
