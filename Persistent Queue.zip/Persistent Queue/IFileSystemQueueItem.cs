﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Interface for managing fily system based queue items
   /// </summary>
   interface IFileSystemQueueItem : IQueueItem
   {
      /// <summary>
      /// Name of the file
      /// </summary>
      string FilePath { get; set; }

      /// <summary>
      /// Length of the file
      /// </summary>
      int Length { get; set; }

   }
}
