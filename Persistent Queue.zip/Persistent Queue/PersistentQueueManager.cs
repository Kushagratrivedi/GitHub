﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Queue Manager for handling the server crash
   /// </summary>
   public class PersistentQueueManager
   {
      private readonly IFileManager _fileManager;

      public PersistentQueueManager(string _queueLocation)
      {
         _fileManager = new FileManager(_queueLocation);
      }

      /// <summary>
      /// Clean the file system based queue
      /// </summary>
      /// <remarks> 
      /// Stage - Queuing - File has nothing written in it - Safe to delete 
      /// Stage - Queued - File has data in it but unprocessed - Do not delete (keep it as is)
      /// Stage - Dequeuing - File was being processed, but failed to finish - update the status to unprocessed
      /// Stage - Dequeued- File has been processed- Safe to delete
      /// </remarks>
      public void Clean()
      {
         // delete the stage 1 items
         DeleteQueuingItems();

         // delete the stage 4 items
         DeleteDequeuedItems();

         // update the stage 3 to stage 2
         UpdateDequeuingStage();
      }

      /// <summary>
      /// 
      /// </summary>
      public void DeleteQueuingItems()
      {
         var _stageQueuingFiles = _fileManager.Scan(false)
                                              .Where(k => k.EndsWith(StageUtil.GetFileExtension(Stage.Queuing)));

         _fileManager.DeleteAll(_stageQueuingFiles);

      }

      /// <summary>
      /// 
      /// </summary>
      public void DeleteDequeuedItems()
      {
         var _stageDequeuedFiles = _fileManager.Scan(false)
                                              .Where(k => k.EndsWith(StageUtil.GetFileExtension(Stage.Dequeued)));

         _fileManager.DeleteAll(_stageDequeuedFiles);
      }

      /// <summary>
      /// 
      /// </summary>
      public void UpdateDequeuingStage()
      {
         var _stageDequeuingFiles = _fileManager.Scan(false)
                                              .Where(k => k.EndsWith(StageUtil.GetFileExtension(Stage.Dequeuing)));

         foreach (var file in _stageDequeuingFiles)
         {
            try
            {
               _fileManager.Rename(file, Stage.Queued);
            }
            catch (Exception ex)
            {
               Console.WriteLine(string.Format("Unable to update the file stage, File = {0}", file));
            }
         }
      }

   }
}
