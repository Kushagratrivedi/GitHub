﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Implementation of <see cref="IPersistentQueue"/>
   /// </summary>
   public class PersistentQueue : IPersistentQueue
   {
      private readonly IQueueService _queueService;

      /// <summary>
      /// Default Constructor
      /// </summary>
      public PersistentQueue(string _queueLocation)
      {
         _queueService = new QueueService(_queueLocation);
      }
      
      /// <summary>
      /// Number of items currently unprocessed in Queue
      /// </summary>
      public int Count
      {
         get
         {
            return _queueService.GetUnprocessedFileCounts();
         }
      }

      /// <summary>
      /// Dequeues the item from the persistent queue
      /// </summary>
      /// <returns></returns>
      public object Dequeue(out string name)
      {
         IQueueItem queueItem = _queueService.Dequeue();

         if (queueItem == null || 
            string.IsNullOrEmpty(queueItem.Name) || 
            queueItem.Data == null)
         {
            throw new Exception("Unable to dequeue the item form persistent queue");
         }

         name = queueItem.Name;

         return queueItem.Data;
      }

      /// <summary>
      /// Enqueues the newly received item 
      /// </summary>
      /// <param name="item"></param>
      public void Enqueue(object item)
      {
         if (item == null)
         {
            throw new ArgumentNullException("item cannot be null");
         }

         _queueService.Enqueue(item);
      }

      /// <summary>
      /// Checks the wether the persistent queue is emtpy
      /// </summary>
      /// <returns></returns>
      public bool IsEmpty()
      {
         return this.Count == 0;
      }

      /// <summary>
      /// Removes the item from the persistent queue
      /// </summary>
      /// <param name="name"></param>
      public void Acknowledge(string name)
      {
         this._queueService.AcknowledgeItemProcessed(name);
      }
   }
}
