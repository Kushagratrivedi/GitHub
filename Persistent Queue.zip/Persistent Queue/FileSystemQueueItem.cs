﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Implementation of <see cref="IFileSystemQueueItem"/>
   /// </summary>
   public class FileSystemQueueItem : IFileSystemQueueItem
   {
      private Stage _stage = Stage.Unknown;
      private string _filePath;
      private int _length;
      private object _data;
      private static readonly object syncLock = new object();

      /// <summary>
      /// Default Constructor
      /// </summary>
      public FileSystemQueueItem()
      {
         
      }

      #region Properties
      /// <summary>
      /// Get the current stage of the queued item
      /// </summary>
      public Stage CurrentStage
      {
         get
         {
            return this._stage;
         }

         set
         {
            lock (syncLock)
            {
               this._stage = value;
            }
         }
      }
      
      /// <summary>
      /// Name of the file which contains the data
      /// </summary>
      public string FilePath
      {
         get
         {
            return this._filePath;
         }

         set
         {
            lock (syncLock)
            {
               this._filePath = value;
            }
         }
      }

      /// <summary>
      /// Length of the file in bytes
      /// </summary>
      public int Length
      {
         get
         {
            return _length;
         }

         set
         {
            lock (syncLock)
            {
               _length = value;
            }
         }
      }

      /// <summary>
      /// Name of the file
      /// </summary>
      public string Name
      {
         get
         {
            return System.IO.Path.GetFileName(this._filePath);
         }
      }

      /// <summary>
      /// Data of the item
      /// </summary>
      public object Data
      {
         set
         {
            lock (syncLock)
            {
               this._data = value;
            }
         }
         get
         {
            return this._data;
         }
      }

      #endregion


   }
}
