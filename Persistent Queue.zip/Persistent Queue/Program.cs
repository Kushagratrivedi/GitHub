﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PersistentQueue
{
   class Program
   {
      private static IPersistentQueue queue;
      private static PersistentQueueManager _manager = null;
      private static object _lock = new object();
      private static Random random = new Random();
      static void Main(string[] args)
      {
         Timer timer = null;
         try
         {
            _manager = new PersistentQueueManager(@"C:\Users\ktrivedi\Documents\PersistentQueueTest");
            _manager.Clean();

            queue = new PersistentQueue(@"C:\Users\ktrivedi\Documents\PersistentQueueTest");
            Thread t1 = new Thread(new ThreadStart(Enqueue));
            Thread t2 = new Thread(new ThreadStart(Dequeue));
            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();

            
            timer = new Timer(CleanProcessedItems, null, 0, 10000);

         }
         catch (Exception e)
         {
            Console.WriteLine(e.StackTrace);
         }
         finally
         {
            if (timer != null)
            {
               timer.Dispose();
            }
         }
      }

      static void Enqueue()
      {
         int i = 0;
         while(i < 10)
         {
            i++;
            var start = DateTime.Now.Ticks;
            string test = RandomString(4000);
            queue.Enqueue(test);
            var ednd = DateTime.Now.Ticks;
            Console.WriteLine(string.Format("Enqueue Time -> {0}", (ednd - start)));
         }
      }

      static void Dequeue()
      {
         while (true)
         {
            if (!queue.IsEmpty())
            {
               var start = DateTime.Now.Ticks;
               string test = null;
               queue.Dequeue(out test);
               //Thread.Sleep(1000);
               queue.Acknowledge(test);
               var ednd = DateTime.Now.Ticks;
               Console.WriteLine(string.Format("Dequeque Time -> {0}", (ednd - start)));
            }
         }
      }

      static void CleanProcessedItems(object o)
      {
         _manager.DeleteDequeuedItems();
      }

      static string RandomString(int length)
      {
         const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
         return new string(Enumerable.Repeat(chars, length)
           .Select(s => s[random.Next(s.Length)]).ToArray());
      }

   }
}
