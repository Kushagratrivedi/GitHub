﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Interface to manage file operations
   /// </summary>
   public interface IFileManager
   {

      /// <summary>
      /// Gets current working directory
      /// </summary>
      string WorkingDirectory { get; }

      /// <summary>
      /// Create a new file
      /// </summary>
      /// <returns>the newly created file path</returns>
      string CreateFile();

      /// <summary>
      /// Write data to the file
      /// </summary>
      void Write(byte [] buffer, string filePath);

      /// <summary>
      /// Reads the file to a buffer
      /// </summary>
      /// <param name="fileName">path of the file</param>
      /// <returns>buffer filled with the file data</returns>
      byte[] Read(string fileName);

      /// <summary>
      /// Renames the file
      /// </summary>
      string Rename(string fileName, Stage newStagstage);

      /// <summary>
      /// delete the file
      /// </summary>
      /// <param name="fileName">path to the file to be deleted</param>
      void Delete(string fileName);

      /// <summary>
      /// Deletes all the files listed
      /// </summary>
      /// <param name="files"></param>
      void DeleteAll(IEnumerable<string> files);

      /// <summary>
      /// Scans throgh the directory path 
      /// </summary>
      /// <param name="includePath"><c>true</c>returns absolute file path, otherwise <c>file name</c></param>
      /// <returns>list of the files under the directory</returns>
      IEnumerable<string> Scan(bool includePath);

      /// <summary>
      /// Gets the oldest file from the directory
      /// </summary>
      /// <returns></returns>
      string GetLeastRecentFile();
      
   }
}
