﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistentQueue
{
   /// <summary>
   /// Interface for managing file system based persistent queue
   /// </summary>
   public interface IPersistentQueue
   {
      /// <summary>
      /// Current number of unprocessed items in queue
      /// </summary>
      int Count { get; }

      /// <summary>
      /// Dequeues the item from the queue
      /// </summary>
      /// <returns></returns>
      object Dequeue(out string name);

      /// <summary>
      /// Enqueues the item to the queue
      /// </summary>
      /// <param name="item"></param>
      void Enqueue(object item);

      /// <summary>
      /// Checks whether the queue is empty
      /// </summary>
      /// <returns></returns>
      bool IsEmpty();

      /// <summary>
      /// Remove the item from queue
      /// </summary>
      /// <param name="name"></param>
      void Acknowledge(string name);
   }
}
