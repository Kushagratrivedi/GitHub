﻿using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PersistentQueue
{
   /// <summary>
   /// Utility class for serializing/deserializing object
   /// </summary>
   public static class Serializer
   {
      /// <summary>
      /// Serializes the object to the byte array
      /// </summary>
      /// <param name="item">queue item</param>
      /// <returns>serialized object</returns>
      public static byte[] Serialize(object item)
      {
         BinaryFormatter bf = new BinaryFormatter();
         using (var ms = new MemoryStream())
         {
            bf.Serialize(ms, item);
            return ms.ToArray();
         }
      }

      /// <summary>
      /// Deserializes the byte array to the object
      /// </summary>
      /// <param name="buffer">byte array</param>
      /// <returns>Deserialized object</returns>
      public static object Deserialize(byte[] buffer)
      {
         using (var memStream = new MemoryStream())
         {
            var binForm = new BinaryFormatter();
            memStream.Write(buffer, 0, buffer.Length);
            memStream.Seek(0, SeekOrigin.Begin);
            var obj = binForm.Deserialize(memStream);
            return obj;
         }
      }
   }
}
